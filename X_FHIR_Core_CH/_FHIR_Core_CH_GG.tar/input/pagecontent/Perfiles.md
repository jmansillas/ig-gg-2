### Perfiles Core

Los siguientes son el listado de perfiles definidos para el Core Nacional
<br>
<br>

**A**
<br>

* [CL Auditoría](StructureDefinition-AuditEventCl.html)
<br>

**B**
<br>

* [CL Bundle](StructureDefinition-BundleCl.html)
<br>

**D**
<br>

* [CL Documento](StructureDefinition-DocumentoCl.html)
* [CL Diagnóstico-Condición](StructureDefinition-CoreDiagnosticoCl.html)
<br>

**E**
<br>

* [CL Encuetro](StructureDefinition-EncounterCL.html)
* [CL Especialidad_Prestador](StructureDefinition-VSEspecialidadesDeisCL.html)
<br>

**I**
<br>

* [CL Inmunizacion](StructureDefinition-ImmunizationCL.html)
<br>

**L**
<br>

* [CL Localización](StructureDefinition-CoreLocalizacionCl.html)
<br>

**M**
<br>

* [CL Medicamento](StructureDefinition-CoreMedicamentoCl.html)
<br>

**O**
<br> 

* [CL Organización](StructureDefinition-CoreOrganizacionCl.html)
<br>

**P**
<br>

* [CL Paciente](StructureDefinition-CorePacienteCl.html)
* [CL Prestador](StructureDefinition-CorePrestadorCl.html)
* [CL Provenance](StructureDefinition-ProvenanceCl.html)